# 🔐 PermissionCreep — Advanced JWT & OAuth Token Security Analyser

> **Zero-knowledge architecture** — All analysis happens client-side. No token data ever leaves your browser.

![React](https://img.shields.io/badge/React-18-blue)
![Vite](https://img.shields.io/badge/Vite-5+-purple)
![D3.js](https://img.shields.io/badge/D3.js-v7-orange)
![Tailwind](https://img.shields.io/badge/Tailwind-v3-blue)
![License](https://img.shields.io/badge/License-MIT-green)

## 🎯 Overview

PermissionCreep is a production-ready, client-side JWT and OAuth token security analyser that performs comprehensive security assessments using a deterministic, OWASP-mapped rule engine. It provides instant visual feedback through interactive D3.js permission graphs and generates CI/CD-ready SARIF reports.

**Author:** Adan Raza Masoom  
**Institution:** Air University, Islamabad  
**Department:** Cyber Security  
**Track:** Offensive Security & Vulnerability Assessment

---

## 🚀 Features

### Layer 1 — Input & Decode
- Accepts raw JWT strings, `Bearer` headers, and OAuth opaque tokens
- Automatic format detection (JWT, OAuth opaque, API keys)
- Validates structural integrity and decodes header/payload
- Supports tokens from Google, GitHub, AWS, Azure, Slack, Stripe, etc.

### Layer 2 — Rule Engine (12 OWASP-Mapped Security Checks)
| Rule | Check | OWASP | Severity |
|------|-------|-------|----------|
| R01 | Algorithm security (alg:none, HS256, confusion) | A02:2021 | CRITICAL/HIGH |
| R02 | Token expiry (missing/excessive TTL) | A07:2021 | HIGH/MEDIUM |
| R03 | Wildcard/Admin scope detection | A01:2021 | CRITICAL/HIGH |
| R04 | Missing audience claim (aud) | A01:2021 | HIGH |
| R05 | Missing issuer claim (iss) | A07:2021 | MEDIUM |
| R06 | Embedded role/permission claims | A01:2021 | MEDIUM |
| R07 | Weak secret detection (HS* brute-force) | A02:2021 | CRITICAL/MEDIUM |
| R08 | PII exposure in payload (SSN/CC/phone/email) | A02:2021 | HIGH/MEDIUM/LOW |
| R09 | Missing JWT ID for revocation (jti) | A07:2021 | LOW |
| R10 | Over-privileged scope count (>5 scopes) | A01:2021 | MEDIUM |
| R11 | Missing key ID (kid) for asymmetric tokens | A02:2021 | MEDIUM |
| R12 | Missing temporal claims (iat/nbf) | A07:2021 | LOW |

### Layer 3 — Scope Analyser & Blast Radius
- Maps scopes to resource categories (Users, Files, Email, Admin, Code, etc.)
- Computes blast-radius percentage score
- Interactive D3.js v7 force-directed permission graph
- Radar chart visualization with severity colouring
- Supports Google, GitHub, AWS, Azure, Okta, and generic scopes

### Layer 4 — Risk Report & Export
- **SARIF 2.1.0** — CI/CD integration (GitHub Code Scanning, Azure DevOps, SonarQube)
- **PDF Audit Report** — Cover page, executive summary, findings, remediation checklist
- **JSON Report** — Machine-readable structured analysis
- Overall risk scoring (0-100) with capped category weighting

### Token Comparison (Dev vs Production)
- Side-by-side environment comparison
- Scope delta analysis (added/removed permissions)
- Algorithm downgrade detection
- Security regression scoring

---

## 🛠️ Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Frontend | React 18 + Vite | Concurrent rendering, sub-second HMR |
| Styling | Tailwind CSS v3 | Utility-first responsive design |
| Visualisation | D3.js v7 | Force-directed permission graph |
| PDF Export | jsPDF | Client-side PDF generation |
| Report Format | SARIF 2.1.0 | CI/CD pipeline integration |
| Deployment | Vercel | Static hosting with global CDN |

---

## 📦 Installation & Running

### Prerequisites
- **Node.js** ≥ 18.x
- **npm** ≥ 9.x

### Quick Start

```bash
# 1. Clone or extract the project
cd PermissionCreep

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# 4. Open in browser
#    → http://localhost:5173
```

### Production Build

```bash
# Build optimized production bundle
npm run build

# Preview production build locally
npm run preview
```

### Deploy to Vercel

```bash
# Install Vercel CLI (one time)
npm i -g vercel

# Deploy
vercel --prod
```

---

## 📖 Usage Guide

### Single Token Analysis
1. Open the app in your browser
2. Paste a JWT, OAuth token, or API key in the input field
3. View instant security analysis:
   - Risk score gauge (0-100)
   - Decoded header and payload claims
   - Security findings with OWASP/CWE references
   - Blast radius radar chart
   - Interactive D3.js permission graph

### Dev vs Production Comparison
1. Click "COMPARE" mode in the header
2. Paste development token in the left panel
3. Paste production token in the right panel
4. View comparison delta:
   - Score regression detection
   - Claim differences highlighted
   - Security-relevant changes flagged

### Exporting Reports
- **SARIF** → Upload to GitHub Code Scanning or Azure DevOps
- **PDF** → Include in penetration testing deliverables
- **JSON** → Process programmatically in CI/CD pipelines

---

## 🔒 Privacy & Security

- **Zero-knowledge architecture** — No token data is transmitted to any server
- **Fully stateless** — No localStorage, no cookies, no analytics
- **Client-side only** — All cryptographic evaluation happens in the browser's V8 runtime
- **Safe for production tokens** — Use with real tokens without risk of exposure

---

## 📁 Project Structure

```
PermissionCreep/
├── public/
│   └── favicon.svg
├── src/
│   ├── engine/                 # Core analysis logic
│   │   ├── constants.js        # Scope knowledge base, resource categories
│   │   ├── decoder.js          # Layer 1: Token parsing & decode
│   │   ├── ruleEngine.js       # Layer 2: 12 OWASP-mapped security rules
│   │   ├── scopeAnalyser.js    # Layer 3: Scope analysis & blast radius
│   │   ├── riskReport.js       # Layer 4: Risk scoring & comparison
│   │   └── index.js            # Public API exports
│   ├── components/             # React UI components
│   │   ├── TokenPanel.jsx      # Main analysis panel
│   │   ├── CompareView.jsx     # Token diff view
│   │   ├── RiskGauge.jsx       # Semi-circular score gauge
│   │   ├── BlastRadiusChart.jsx # Radar chart visualization
│   │   └── D3PermissionGraph.jsx # D3.js force-directed graph
│   ├── exports/                # Report generation
│   │   ├── sarifExport.js      # SARIF 2.1.0 generator
│   │   ├── pdfExport.js        # PDF audit report (jsPDF)
│   │   └── jsonExport.js       # JSON report
│   ├── App.jsx                 # Main application component
│   ├── main.jsx                # Entry point
│   └── index.css               # Tailwind directives + custom styles
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── README.md
```

---

## 🧪 Sample Tokens for Testing

The app includes built-in sample tokens:

1. **⚠ alg:none** — Unsigned token (CRITICAL vulnerability)
2. **🔑 Weak HS256** — jwt.io default secret token
3. **👑 Over-privileged** — Token with admin:* and wildcard scopes
4. **✓ Well-configured** — Properly secured RS256 token with kid

---

## 📋 OWASP Top 10 Coverage

| OWASP ID | Category | Token Manifestation |
|----------|----------|-------------------|
| A01:2021 | Broken Access Control | Wildcard scopes, admin roles, missing audience |
| A02:2021 | Cryptographic Failures | alg:none, weak HS256, missing kid, PII exposure |
| A07:2021 | Identification & Auth Failures | Missing exp/nbf/iat, no jti for revocation |

---

## 📄 License

MIT License — Free for educational and commercial use.

---

## 🙏 Acknowledgments

- **OWASP Foundation** — Top 10 security framework
- **IETF** — RFC 7515 (JWS), RFC 7519 (JWT), RFC 7516 (JWE)
- **SARIF TC** — Static Analysis Results Interchange Format specification
- **Air University, Islamabad** — Academic guidance and support
