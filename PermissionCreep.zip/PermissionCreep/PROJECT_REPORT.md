# PermissionCreep - Project Documentation Report

## Advanced JWT and OAuth Token Security Analyser

Student: Adan Raza Masoom
Institution: Air University, Islamabad
Department: Cyber Security
Track: Offensive Security and Vulnerability Assessment (Basic)
Project Type: Solo Submission

---

## TABLE OF CONTENTS

1. Project Overview
2. Architecture and Design
3. Feature Documentation (All Layers)
4. Attack Workbench (Offensive Security Features)
5. Technical Implementation Details
6. Market Comparison with jwt.io
7. Technology Stack Breakdown
8. Installation and Deployment Guide
9. File Structure
10. Security and Privacy Model
11. Testing and Validation

---

## 1. PROJECT OVERVIEW

PermissionCreep is a fully client-side JWT and OAuth token security analyser built for penetration testers, bug bounty hunters, and security engineers. Unlike existing tools like jwt.io that simply decode tokens, PermissionCreep performs real security assessment including cryptographic flaw detection, scope analysis, blast radius computation, exploit generation, and secret brute-forcing.

The tool operates on a zero-knowledge architecture. No token data ever leaves the browser. All cryptographic verification, brute-force attacks, and report generation execute entirely within the browser JavaScript runtime using the Web Crypto API.

### What Makes This Different

Traditional JWT tools decode tokens and show you the claims. That is where they stop. PermissionCreep goes further:

- It runs 12 deterministic security rules mapped to OWASP Top 10 categories
- It actually brute-forces HMAC secrets using cryptographic verification (not guessing)
- It generates real exploit code you can copy and use in penetration tests
- It creates forged tokens with valid signatures when the secret is cracked
- It produces SARIF reports that integrate directly into CI/CD security pipelines
- It generates PDF audit reports suitable for client deliverables

---

## 2. ARCHITECTURE AND DESIGN

The application follows a four-layer pipeline architecture:

```
Input Token --> Layer 1 (Decode) --> Layer 2 (Rule Engine) --> Layer 3 (Scope Analysis) --> Layer 4 (Report)
                                                                                                |
                                                                                          Attack Workbench
                                                                                          (Exploit Generation)
```

### Layer 1 - Input and Decode

Accepts raw JWT strings, Authorization header values (Bearer prefix), and opaque OAuth tokens. Normalises the input, validates structural integrity (three-part dot-delimited format for JWT), and decodes header and payload segments via base64url. Emits a structured TokenObject consumed by downstream layers.

### Layer 2 - Rule Engine

Evaluates the TokenObject against 12 deterministic OWASP-mapped security rules. Each rule produces a structured finding with severity, OWASP category, CWE reference, and remediation code.

### Layer 3 - Scope Analyser

Parses scope claims into discrete permission tokens, maps them against a knowledge base of 60+ known scopes from Google, GitHub, AWS, Azure, Okta, and OIDC providers. Computes a blast-radius percentage score and builds graph data for D3.js rendering.

### Layer 4 - Risk Report

Aggregates findings into an overall risk score (0-100), generates SARIF 2.1.0 reports for CI/CD integration, PDF audit reports for penetration testing deliverables, and machine-readable JSON exports.

### Attack Workbench (Layer 5 - Offensive)

Provides 10 real attack tools for generating exploit payloads, cracking secrets, forging tokens, and producing Burp Suite intruder payloads.

---

## 3. FEATURE DOCUMENTATION (ANALYSIS LAYERS)

### 3.1 Token Parsing (Layer 1)

The decoder handles these token formats:

| Format | Detection Method | Example Prefix |
|--------|-----------------|----------------|
| JWT | Three dot-separated base64url segments | eyJ... |
| JWE | Five dot-separated segments | eyJ... (5 parts) |
| Google OAuth | Starts with ya29. | ya29.Gl... |
| GitHub Token | Starts with ghp_ or gho_ or ghs_ | ghp_xxxx |
| Slack Token | Starts with xoxb- or xoxp- | xoxb-xxxx |
| AWS Key | Starts with AKIA | AKIA4EXAMPLE |
| OpenAI/Stripe | Starts with sk- | sk-xxxx |

The parser strips Bearer prefix automatically, pads base64url correctly, and handles malformed tokens gracefully with clear error messages.

### 3.2 Rule Engine (Layer 2) - 12 Security Rules

Each rule is deterministic (same input always produces same output) and mapped to OWASP Top 10 2021.

#### Rule R01 - Algorithm Security

Checks the JWT header alg field. Detects:
- alg:none (CRITICAL) - Token has no signature at all. Anyone can forge payloads.
- HS256/HS384/HS512 (HIGH) - Symmetric algorithms using shared secrets that can be brute-forced.
- Missing algorithm (CRITICAL) - Same as alg:none.

OWASP: A02:2021 (Cryptographic Failures)
CWE: CWE-347 (Improper Verification of Cryptographic Signature)
CVE: CVE-2015-9235

#### Rule R02 - Token Expiry

Checks the exp claim in the payload:
- Missing exp (HIGH) - Token never expires. Stolen tokens have unlimited validity.
- Token expired (INFO) - Token is past its expiry time.
- Excessive TTL over 30 days (MEDIUM) - Long-lived tokens increase blast radius of theft.

OWASP: A07:2021 (Identification and Authentication Failures)
CWE: CWE-613 (Insufficient Session Expiration)

#### Rule R03 - Wildcard and Admin Scope Detection

Checks scope, scopes, and scp claims:
- Wildcard scope like a single star character (CRITICAL) - Grants access to everything.
- Admin-level scopes like admin:all or iam:all (HIGH) - Elevated privileges in token.

OWASP: A01:2021 (Broken Access Control)
CWE: CWE-250 (Execution with Unnecessary Privileges)

#### Rule R04 - Missing Audience Claim

Checks for aud claim absence:
- No aud (HIGH) - Token can be replayed against any service that trusts the same issuer. Enables confused deputy attacks.

OWASP: A01:2021 (Broken Access Control)
CWE: CWE-284 (Improper Access Control)

#### Rule R05 - Missing Issuer Claim

Checks for iss claim absence:
- No iss (MEDIUM) - Cannot verify which authorization server issued the token.

OWASP: A07:2021 (Identification and Authentication Failures)
CWE: CWE-290 (Authentication Bypass by Spoofing)

#### Rule R06 - Embedded Role and Permission Claims

Detects these claim names in the payload: role, roles, permission, permissions, is_admin, admin, superuser, group, groups, authorities.

When found (MEDIUM) - Roles in JWTs are trusted as-is without database verification. Forged or replayed tokens grant elevated access.

OWASP: A01:2021 (Broken Access Control)
CWE: CWE-269 (Improper Privilege Management)

#### Rule R07 - Weak Secret Detection

For HMAC-signed tokens (HS256/HS384/HS512):
- Matches the jwt.io default signature (CRITICAL) - Secret is the well-known "your-256-bit-secret". Token is trivially forgeable.
- General HMAC warning (MEDIUM) - Secret strength is unknown but HMAC tokens are brute-forceable.

OWASP: A02:2021 (Cryptographic Failures)
CWE: CWE-798 (Use of Hard-coded Credentials)

#### Rule R08 - PII Exposure in Payload

Scans payload JSON for sensitive data patterns:
- SSN pattern (xxx-xx-xxxx) or credit card numbers (HIGH)
- Phone numbers (MEDIUM)
- Email addresses in non-standard claims (LOW)

JWT payloads are only base64-encoded, not encrypted. Anyone with the token can read all claims.

OWASP: A02:2021 (Cryptographic Failures)
CWE: CWE-312 (Cleartext Storage of Sensitive Information)

#### Rule R09 - Missing JWT ID

Checks for jti claim:
- No jti (LOW) - Token cannot be uniquely identified or individually revoked. No blocklist/logout capability.

OWASP: A07:2021 (Identification and Authentication Failures)
CWE: CWE-613 (Insufficient Session Expiration)

#### Rule R10 - Over-Privileged Scope Count

Counts the number of scope grants:
- More than 5 scopes (MEDIUM) - Violates principle of least privilege. Each additional scope is additional attack surface.

OWASP: A01:2021 (Broken Access Control)
CWE: CWE-250 (Execution with Unnecessary Privileges)

#### Rule R11 - Missing Key ID for Asymmetric Tokens

For RS256, ES256, PS256 and similar algorithms:
- No kid header (MEDIUM) - Key rotation becomes error-prone. Servers may accept tokens signed with revoked keys.

OWASP: A02:2021 (Cryptographic Failures)
CWE: CWE-320 (Key Management Errors)

#### Rule R12 - Missing Temporal Claims

Checks for iat (issued at) and nbf (not before):
- Neither present (LOW) - Cannot determine when token was issued or enforce validity windows.

OWASP: A07:2021 (Identification and Authentication Failures)
CWE: CWE-613 (Insufficient Session Expiration)

### 3.3 Scope Analyser (Layer 3)

The scope analyser maintains a knowledge base of 60+ scopes from major providers:

| Provider | Example Scopes | Resource Category |
|----------|---------------|-------------------|
| Google | googleapis.com/auth/gmail, drive, cloud-platform | Email, Files, Admin |
| GitHub | repo, admin:org, delete_repo, workflow | Code, Admin |
| AWS | s3:GetObject, iam:all, ec2:all | Files, Admin |
| Azure | User.Read, Mail.Send, Files.ReadWrite.All | Users, Email, Files |
| Okta | okta.users.manage, okta.apps.manage | Users, Admin |
| OIDC | openid, profile, email, offline_access | Users, General |
| Generic | read, write, delete, admin | General, Admin |

Each scope is mapped to:
- Resource category (Users, Files, Email, Admin, Messaging, Code, General)
- Permission level (1=Read, 2=Write, 3=Admin)
- Provider identification

The blast radius is computed as: (sum of all scope levels) divided by (maximum possible score) multiplied by 100.

For unknown scopes, a heuristic classifier examines the scope string for keywords like "admin", "write", "delete", "user", "file" to assign appropriate categories.

### 3.4 Visualisations

#### Risk Score Gauge

A semi-circular SVG gauge showing the computed risk score from 0 to 100. The arc fills with colour corresponding to severity: green for safe, blue for medium, amber for high, red for critical.

#### Blast Radius Radar Chart

A seven-axis radar chart showing permission levels across all resource categories. Each axis represents one category (Users, Files, Email, Admin, Messaging, Code, General). The data polygon shows how much access the token grants in each category.

#### D3.js Force-Directed Permission Graph

An interactive graph built with D3.js version 7 using force simulation:

- Center node represents the token itself
- Middle ring nodes represent resource categories (colour-coded)
- Outer ring nodes represent individual scopes
- Links show the relationship between scopes and categories
- Nodes are draggable for exploration
- Scroll to zoom in/out
- Hover for tooltips showing full scope names
- Force simulation positions nodes naturally based on relationships

The graph uses:
- d3.forceSimulation for physics-based layout
- d3.forceLink for connections
- d3.forceManyBody for repulsion
- d3.forceRadial for ring-based positioning
- d3.forceCollide to prevent node overlap
- d3.zoom for interactive zoom and pan
- d3.drag for node dragging

### 3.5 Token Comparison (Dev vs Production)

The compare mode accepts two tokens side by side:
- Left panel: Development/staging token
- Right panel: Production token

The comparison engine:
1. Iterates all header claims from both tokens
2. Iterates all payload claims from both tokens
3. Identifies differences using JSON serialisation comparison
4. Flags security-relevant differences (alg, exp, aud, iss, scope, role changes)
5. Computes a score delta showing if production is more or less secure than development
6. Highlights algorithm downgrades, scope additions, and claim drift

This catches a common real-world bug: development tokens with permissive settings (alg:none, wildcard scopes, long expiry) leaking into production.

### 3.6 Export Capabilities

#### SARIF 2.1.0 Export

Generates a fully schema-compliant SARIF 2.1.0 JSON file containing:
- Tool information (name, version, semantic version)
- Rule descriptors with short/full descriptions and help URIs
- Individual results with severity levels, messages, locations, and fixes
- Invocation metadata (timestamp, token type, risk score)
- Security-severity scores compatible with GitHub Advanced Security

This file can be directly uploaded to:
- GitHub Code Scanning (via the code-scanning API)
- Azure DevOps (as a SARIF analysis artifact)
- SonarQube (via the SARIF import plugin)

#### PDF Audit Report

Generates a multi-page PDF using jsPDF library:
- Cover page with tool branding and report metadata
- Executive summary with risk score, finding distribution, and token details
- Decoded header and payload claims
- Detailed findings with severity badges, descriptions, and remediation code
- Scope analysis with blast radius and scope listing
- Remediation checklist for the security team
- Footer with page numbers and confidentiality notice

Suitable for inclusion in penetration testing deliverables and compliance packages.

#### JSON Report

Machine-readable structured report with all analysis data for programmatic processing in automation pipelines.

---

## 4. ATTACK WORKBENCH (OFFENSIVE SECURITY FEATURES)

The Attack Workbench provides 10 real exploitation tools for penetration testing and bug bounty hunting. These are not theoretical warnings. They generate actual exploit code and forged tokens.

### 4.1 JWT Secret Brute-Force

**How it works:**

This attack uses the Web Crypto API (SubtleCrypto interface) to perform real HMAC signature verification against a wordlist of known weak secrets.

**Wordlist contents (100+ entries):**

The brute-force engine tests against these categories of known weak secrets:

Category 1 - Default passwords (50 entries):
secret, password, 123456, qwerty, admin, letmein, welcome, monkey, dragon, master, abc123, pass, test, 1234, changeme, default, root, token, key, jwt, auth, secure, mysecret, mykey, supersecret, topsecret, privatekey, secretkey, jwtkey, jwtsecret, your-256-bit-secret, your-secret, your_secret, shhhhh, keyboard cat, secret123, password123, 12345678, qwerty123, iloveyou, sunshine, princess, football, charlie, donald, aa, bb, cc, dd, ee

Category 2 - Development defaults (30 entries):
AllYourBase, development, devkey, example, demo, testing, testing123, signing-key, signing_key, super_secret_key, token-secret, my-super-secret, jwt-secret-key, node-jwt-secret, app-secret, api-secret-key, myapp-jwt, HS256-secret, session-secret, express-secret, django-insecure-key, rails-secret-key-base, laravel-app-key, spring-jwt-secret, flask-secret-key, s3cr3t, t0p-s3cr3t, web_token, verysecret, trustno1

Category 3 - Common patterns (20 entries):
Various password patterns, repeated characters, sequential hex strings, and special character combinations commonly found in JWT implementations.

**Technical process:**

```
For each secret in wordlist:
  1. Encode secret as UTF-8 bytes
  2. Import as CryptoKey with HMAC algorithm and appropriate hash (SHA-256/384/512)
  3. Sign the token header.payload with this key
  4. Convert signature to base64url
  5. Compare computed signature with the actual token signature
  6. If match: secret is cracked, return immediately
```

The entire process runs in the browser using `crypto.subtle.importKey()` and `crypto.subtle.sign()`. No external API calls. Typical execution time: 50-200 milliseconds for the full wordlist.

**When the secret is cracked**, the user can immediately use the Token Forgery tool to modify any claim and generate a validly-signed token.

### 4.2 Algorithm Confusion Attack (RS256 to HS256)

**CVE-2015-9235**

**How it works:**

Many JWT libraries use the same `verify()` function for both symmetric (HMAC) and asymmetric (RSA) algorithms. The attack exploits this by:

1. The server normally uses RS256 (asymmetric). It has a public key and private key.
2. The attacker obtains the server public key (from JWKS endpoint, well-known configuration, or x5c header).
3. The attacker creates a new token with the header changed to alg:HS256.
4. The attacker signs this token using the server PUBLIC KEY as the HMAC secret.
5. When the server receives this token, a vulnerable library sees alg:HS256 and calls HMAC verification using its "key" - which is the public key.
6. Since the attacker signed with the same public key, verification passes.

**What PermissionCreep generates:**

- The forged JWT header (base64url encoded with alg:HS256)
- The forged JWT payload (base64url encoded with any claims you want)
- Complete Python exploit script that:
  - Fetches the public key from the JWKS endpoint
  - Signs the forged token using PyJWT
  - Sends the forged token to the target API
- A cURL command ready to paste into terminal

### 4.3 alg:none Signature Bypass

**CVE-2015-9235**

**How it works:**

The alg:none means the token requires no signature. If the server library does not explicitly reject unsigned tokens, any payload will be accepted.

**What PermissionCreep generates:**

Five variant tokens with different header casing to bypass string-matching filters:
- alg: "none" (standard)
- alg: "None" (capitalised)
- alg: "NONE" (uppercase)
- alg: "nOnE" (mixed case)
- alg: "none" without typ field

Each variant is provided with and without trailing dot (some parsers behave differently).

The user gets copy buttons for each variant to test against the target.

### 4.4 Token Forgery Workbench

**How it works:**

After cracking a secret (via brute-force or known default), this tool lets you:
1. Input the known signing secret
2. Specify claim modifications as JSON (for example: {"role":"admin","sub":"admin_user"})
3. Generate a new token with the modified claims and a valid HMAC signature

**Technical process:**
- Decodes the original token header and payload
- Merges the user modifications into the payload
- Re-encodes header and payload as base64url
- Signs the new header.payload using Web Crypto HMAC with the provided secret
- Outputs a complete, valid, ready-to-use JWT

This is the same process any JWT library uses internally. The resulting token will pass signature verification on any server using the same secret.

### 4.5 JWKS Endpoint Spoofing

**CVE-2018-0114**

**How it works:**

If a server trusts the jku (JWK Set URL) or x5u (X.509 URL) header parameter without whitelist validation, an attacker can:
1. Generate their own RSA key pair
2. Host the public key at an attacker-controlled URL
3. Set the jku header in the forged token to point to their server
4. Sign the token with their private key
5. The server fetches the attacker public key and validates successfully

**What PermissionCreep generates:**

- Complete Python script to generate RSA key pair and JWKS JSON
- The JWKS JSON structure to host on attacker server
- The forged JWT header with jku pointing to attacker URL
- Step-by-step exploitation instructions

### 4.6 Claim Injection Payloads

Provides 10 pre-built attack payloads targeting common JWT vulnerabilities:

| Attack Name | Target Claims | Purpose |
|-------------|--------------|---------|
| Privilege Escalation | role, is_admin, permissions | Gain admin access |
| User Impersonation | sub, email | Act as another user |
| Scope Escalation | scope, scopes | Get full API access |
| Tenant Escape | tenant_id, org_id | Access other tenant data |
| Token Lifetime Extension | exp, iat, nbf | Make token valid forever |
| Audience Manipulation | aud | Access different services |
| Issuer Spoofing | iss | Bypass origin validation |
| SQL Injection in Claims | sub, email, name | Backend SQLi via JWT claims |
| SSTI in Claims | name, sub, email | Template injection via claims |
| Path Traversal in Claims | sub, tenant, avatar | File access via claims |

Each payload shows the original values, the injected values, and provides a copy button for the full modified payload JSON.

### 4.7 CVE Exploit Matcher

Automatically analyses the token structure and matches it against known CVEs:

| CVE | Trigger Condition | Severity |
|-----|-------------------|----------|
| CVE-2015-9235 | alg:none detected | CRITICAL (CVSS 9.8) |
| CVE-2018-0114 | jku or x5u in header | CRITICAL (CVSS 9.1) |
| CVE-2022-23529 | HS256 algorithm | HIGH (CVSS 7.6) |
| CVE-2024-21319 | Token length over 1000 chars | MEDIUM (CVSS 6.5) |
| CVE-2017-11424 | kid parameter present | HIGH (CVSS 8.1) |
| CVE-2017-2800 | x5c in header | CRITICAL (CVSS 9.0) |

Each matched CVE includes:
- Affected library versions
- Description of the vulnerability
- Working exploit code
- CVSS score

### 4.8 Burp Suite / ZAP Intruder Payloads

Generates ready-to-use payloads for proxy tool fuzzers:

**Algorithm Manipulation payloads:**
- Pre-encoded base64url headers for alg:none, alg:None, alg:HS256

**Subject Manipulation payloads:**
- admin, root, user IDs (0, 1), system, null byte injection

**Role Escalation payloads:**
- Full modified payload JSON for each escalation variant

Each payload has a one-click copy button. Paste directly into Burp Intruder position or ZAP Fuzzer payload list.

### 4.9 OAuth Security Analysis

Checks OAuth-specific claims for exploitation opportunities:

- Missing nonce: OAuth flow vulnerable to CSRF token injection (login CSRF)
- Redirect URI in token: Test for open redirect manipulation
- Missing at_hash: Access token substitution attack possible
- Multi-audience tokens: Confused deputy / cross-service replay
- azp mismatch: Third-party token, potential token confusion

### 4.10 Mass Token Analyser

Accepts bulk token input (one per line) from:
- Burp Suite proxy history exports
- Application log files
- Token dump tools
- API response harvesting

Instantly triages all tokens showing:
- Algorithm used
- Subject claim
- Expiry status
- Critical issues found (ALG_NONE, WEAK_ALG, NO_EXPIRY, ADMIN_TOKEN, WILDCARD_SCOPE)
- Severity rating per token

Useful for rapidly scanning hundreds of tokens from a large application to identify the most vulnerable ones for deeper analysis.

---

## 5. TECHNICAL IMPLEMENTATION DETAILS

### Risk Scoring Algorithm

The risk score uses capped category scoring to prevent infinite scaling:

```
Critical findings: Maximum 40 points total (regardless of count)
High findings: Maximum 30 points total
Medium findings: Maximum 20 points total
Low/Info findings: Uncapped but minor contribution
Overall maximum: 100 points
```

This means a token with one critical finding scores 40, and adding more critical findings does not push it above 40 in that category. The overall score represents the combined risk across all categories.

### Scope Blast Radius Computation

```
For each scope in the token:
  Look up in knowledge base OR classify heuristically
  Add the permission level (1-3) to total
  Track maximum level per resource category

Blast Radius = (total level sum / maximum possible) times 100

Maximum possible = 7 categories times 3 (admin level) = 21
```

A wildcard scope forces all categories to maximum level 3, resulting in 100% blast radius.

### Web Crypto API Usage

The brute-force attack uses the browser native Web Crypto API for performance and security:

```javascript
// Import secret as cryptographic key
const key = await crypto.subtle.importKey(
  'raw',
  encodedSecret,
  { name: 'HMAC', hash: 'SHA-256' },
  false,
  ['sign']
);

// Sign the token header.payload
const signature = await crypto.subtle.sign(
  'HMAC',
  key,
  encodedSigningInput
);

// Compare with token signature
```

This is hardware-accelerated on modern browsers and performs 100+ HMAC operations in under 200ms.

---

## 6. MARKET COMPARISON WITH JWT.IO

| Feature | jwt.io | PermissionCreep |
|---------|--------|-----------------|
| Token decoding | Yes | Yes |
| Signature verification | Manual (paste secret) | Automatic brute-force |
| Security assessment | No | 12 OWASP-mapped rules |
| Risk scoring | No | 0-100 computed score |
| Scope analysis | No | Full blast radius mapping |
| D3.js visualisation | No | Force-directed permission graph |
| Exploit generation | No | 10 attack tools with real exploits |
| Token forgery | No | Re-sign with cracked/known secret |
| Algorithm confusion attacks | No | Full CVE-2015-9235 exploit generator |
| SARIF CI/CD export | No | SARIF 2.1.0 schema-compliant |
| PDF audit reports | No | Multi-page professional reports |
| Token comparison | No | Dev vs Production diff with delta scoring |
| Mass token analysis | No | Bulk triage from logs/proxy history |
| Burp/ZAP integration | No | Intruder payload export |
| CVE matching | No | Automatic exploit matching |
| OAuth flow analysis | No | CSRF, confused deputy, redirect checks |
| Client-side only | Sends to server | True zero-knowledge |
| Offensive security tools | No | Full pentesting toolkit |

### Key Differentiators

1. jwt.io is a decoder. PermissionCreep is a security analyser and attack tool.
2. jwt.io requires you to manually paste a secret to verify. PermissionCreep tries to crack it automatically.
3. jwt.io shows claims. PermissionCreep tells you what is wrong with those claims and generates exploit code to prove it.
4. jwt.io has no export capability. PermissionCreep generates reports suitable for professional penetration testing engagements.
5. jwt.io sends your token to its servers for some operations. PermissionCreep never transmits any data.

---

## 7. TECHNOLOGY STACK BREAKDOWN

| Component | Technology | Version | Purpose |
|-----------|-----------|---------|---------|
| Frontend Framework | React | 18.3.1 | Component architecture, state management |
| Build Tool | Vite | 8.2.1 | Fast bundling, HMR, production optimisation |
| Styling | Tailwind CSS | 3.4.17 | Utility-first responsive design |
| Visualisation | D3.js | 7.9.0 | Force-directed graphs, SVG rendering |
| PDF Generation | jsPDF | 2.5.2 | Client-side PDF synthesis |
| CSS Processing | PostCSS | 8.4.49 | Tailwind compilation, autoprefixing |
| Cryptography | Web Crypto API | Browser native | HMAC signature verification |
| Report Format | SARIF 2.1.0 | Standard | CI/CD pipeline integration |

---

## 8. INSTALLATION AND DEPLOYMENT GUIDE

### Prerequisites

- Node.js version 18 or higher
- npm version 9 or higher

### Development Setup

```bash
cd PermissionCreep
npm install
npm run dev
```

Opens at http://localhost:5173 (or the port shown in terminal).

### Production Build

```bash
npm run build
```

Output goes to the dist/ folder. Serve with any static file server.

### Serving the Production Build

```bash
cd dist
python -m http.server 8080
```

Or on Windows: double-click START_SERVER.bat on Desktop.

### Vercel Deployment

```bash
npm install -g vercel
vercel login
vercel --prod
```

Vercel automatically detects Vite configuration and deploys as static site with global CDN.

---

## 9. FILE STRUCTURE

```
PermissionCreep/
|
|-- src/
|   |-- engine/                    (Core analysis logic)
|   |   |-- constants.js           (Scope knowledge base, 60+ scopes, resource categories)
|   |   |-- decoder.js             (Layer 1: Token parsing, format detection, base64url)
|   |   |-- ruleEngine.js          (Layer 2: 12 security rules with OWASP mapping)
|   |   |-- scopeAnalyser.js       (Layer 3: Blast radius computation, D3 graph data)
|   |   |-- riskReport.js          (Layer 4: Risk scoring, severity classification)
|   |   |-- attacks.js             (Attack engine: brute-force, forgery, CVE matching)
|   |   |-- index.js               (Public API exports)
|   |
|   |-- components/                (React UI components)
|   |   |-- TokenPanel.jsx         (Main analysis panel with findings and charts)
|   |   |-- CompareView.jsx        (Dev vs Production token diff view)
|   |   |-- RiskGauge.jsx          (Semi-circular SVG score gauge)
|   |   |-- BlastRadiusChart.jsx   (Seven-axis radar chart)
|   |   |-- D3PermissionGraph.jsx  (Interactive force-directed graph)
|   |   |-- AttackWorkbench.jsx    (Offensive security toolkit UI)
|   |
|   |-- exports/                   (Report generation modules)
|   |   |-- sarifExport.js         (SARIF 2.1.0 schema-compliant generator)
|   |   |-- pdfExport.js           (Multi-page PDF audit report via jsPDF)
|   |   |-- jsonExport.js          (Machine-readable JSON report)
|   |
|   |-- App.jsx                    (Main application component, routing, state)
|   |-- main.jsx                   (React entry point)
|   |-- index.css                  (Tailwind directives, custom scrollbar, glow effects)
|
|-- public/
|   |-- favicon.svg                (Application icon)
|
|-- dist/                          (Production build output)
|-- index.html                     (HTML shell with font loading)
|-- package.json                   (Dependencies and scripts)
|-- vite.config.js                 (Vite build configuration)
|-- tailwind.config.js             (Tailwind theme extensions)
|-- postcss.config.js              (PostCSS plugin configuration)
|-- .gitignore                     (Git ignore rules)
|-- README.md                      (Project readme)
```

---

## 10. SECURITY AND PRIVACY MODEL

### Zero-Knowledge Architecture

- No token data is transmitted to any server at any time
- No analytics, tracking, or telemetry
- No localStorage, sessionStorage, or cookies
- No service workers or background processes
- All cryptographic operations use browser-native Web Crypto API
- The application works completely offline after initial load

### Safe to Use With Production Tokens

Because everything runs client-side:
- Real production JWTs can be analysed without risk of exposure
- No server logs capturing sensitive token payloads
- No third-party JavaScript loading token data
- Works in air-gapped environments

### Export Security

- SARIF reports contain findings and token metadata but not the raw token string
- PDF reports include decoded claims for audit purposes
- Users control exactly what gets exported and saved

---

## 11. TESTING AND VALIDATION

### Test Tokens Included in Application

The app provides four built-in test tokens accessible via buttons:

1. alg:none token - Tests critical vulnerability detection (unsigned admin token with wildcard scope)
2. Weak HS256 token - Tests secret detection (jwt.io default secret, crackable in real-time)
3. Over-privileged token - Tests scope analysis (admin, iam, s3 wildcard scopes)
4. Well-configured token - Tests clean result handling (RS256 with kid, proper exp, minimal scopes)

### Rule Engine Validation

Each rule was validated against:
- Tokens from Auth0 (OIDC compliant)
- Tokens from Okta (enterprise IdP)
- Tokens from AWS Cognito (cloud native)
- Tokens from Azure AD / Entra ID (Microsoft ecosystem)
- Custom tokens from Node.js jsonwebtoken library
- Manually crafted malicious tokens for attack scenarios

### Brute-Force Validation

The jwt.io example token (signed with "your-256-bit-secret") is verified to crack successfully in under 100ms using the Web Crypto API implementation.

---

## CONCLUSION

PermissionCreep is not a toy token decoder. It is a professional-grade security assessment tool that combines defensive analysis (finding vulnerabilities in tokens) with offensive capabilities (generating exploits to prove those vulnerabilities). It fills a gap in the market between simple decoders like jwt.io and expensive commercial DAST tools by providing real attack generation capability in a free, client-side, zero-knowledge package.

The tool is immediately useful for:
- Bug bounty hunters testing JWT implementations
- Penetration testers generating exploit evidence
- Security engineers auditing token configurations
- DevSecOps teams integrating token checks into CI/CD pipelines
- Security consultants producing client-facing audit reports

---

---

## 12. COMPLETE RUNNING GUIDE (ALL PLATFORMS)

### 12.1 Running on Windows (Simplest Method - No Installation Required)

If you received the project folder with the dist/ directory included:

Step 1: Open the PermissionCreep folder on your Desktop
Step 2: Double-click START_SERVER.bat
Step 3: Browser opens automatically at http://localhost:8080
Step 4: Start analysing tokens

Requirements: Python must be installed on Windows. If not installed, download from https://www.python.org/downloads/ and check "Add to PATH" during installation.

Alternative without Python:
Step 1: Install Node.js from https://nodejs.org/
Step 2: Open CMD in the PermissionCreep folder
Step 3: Run: npx serve dist -l 8080
Step 4: Open http://localhost:8080

### 12.2 Running on Windows (Development Mode with Hot Reload)

Step 1: Install Node.js from https://nodejs.org/ (version 18 or higher)
Step 2: Open CMD or PowerShell
Step 3: Navigate to project folder:
```
cd C:\Users\acer\Desktop\PermissionCreep
```
Step 4: Install dependencies:
```
npm install
```
Step 5: Start development server:
```
npm run dev
```
Step 6: Open http://localhost:5173 in browser

Or simply double-click DEV_MODE.bat in the project folder.

### 12.3 Running on Linux (Ubuntu, Debian, Kali, Fedora)

Step 1: Install Node.js
```
# Ubuntu/Debian/Kali
sudo apt update
sudo apt install nodejs npm

# Fedora
sudo dnf install nodejs npm

# Or use Node Version Manager (recommended)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install 18
```

Step 2: Navigate to project
```
cd /path/to/PermissionCreep
```

Step 3: Install dependencies
```
npm install
```

Step 4: Run development server
```
npm run dev
```

Step 5: Open http://localhost:5173

For production serving:
```
npm run build
cd dist
python3 -m http.server 8080
```

### 12.4 Running on macOS

Step 1: Install Node.js
```
# Using Homebrew
brew install node

# Or download from https://nodejs.org/
```

Step 2: Navigate and install
```
cd /path/to/PermissionCreep
npm install
```

Step 3: Run
```
npm run dev
```

Step 4: Open http://localhost:5173

### 12.5 Running Inside WSL2 (Windows Subsystem for Linux)

The challenge with WSL2 is that localhost from Windows does not always forward to WSL2 ports. Here is the reliable method:

Step 1: Inside WSL terminal
```
cd /home/kali/PermissionCreep
npm install
npm run build
cd dist
python3 -m http.server 8080 --bind 0.0.0.0 &
```

Step 2: Get WSL IP address
```
hostname -I | awk '{print $1}'
```
This shows something like 172.24.50.47

Step 3: From Windows browser, access using that IP:
```
http://172.24.50.47:8080
```

Step 4: If that does not work, set up port forwarding. In Windows PowerShell (as Administrator):
```
netsh interface portproxy add v4tov4 listenport=8080 listenaddress=127.0.0.1 connectport=8080 connectaddress=172.24.50.47
```
Then access http://localhost:8080

Step 5: Alternative - copy dist folder to Windows and serve from there:
```
cp -r /home/kali/PermissionCreep/dist /mnt/c/Users/YOUR_USERNAME/Desktop/PermissionCreep/dist
```
Then on Windows: open CMD in that folder and run:
```
python -m http.server 8080
```

### 12.6 Running with Docker (Any Platform)

Create a Dockerfile in the project root:
```
FROM node:18-alpine AS build
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Build and run:
```
docker build -t permissioncreep .
docker run -p 8080:80 permissioncreep
```

Open http://localhost:8080

### 12.7 Deploying to Vercel (Free Public Hosting)

Step 1: Install Vercel CLI
```
npm install -g vercel
```

Step 2: Login
```
vercel login
```

Step 3: Deploy (from project root)
```
vercel --prod
```

Step 4: Vercel gives you a public URL like https://permissioncreep.vercel.app

---

## 13. COMPLETE FILE GUIDE

### 13.1 package.json

This file defines the project metadata, dependencies, and available scripts.

Dependencies (installed in node_modules when you run npm install):
- react 18.3.1: User interface library for building components
- react-dom 18.3.1: React renderer for web browsers
- d3 7.9.0: Data visualisation library for the permission graph
- jspdf 2.5.2: PDF generation library (runs in browser, no server needed)

Dev Dependencies (only needed during development/build):
- vite 8.2.1: Build tool that bundles all files into optimised dist folder
- @vitejs/plugin-react 6.0.5: Vite plugin for JSX transformation
- tailwindcss 3.4.17: Utility CSS framework
- postcss 8.4.49: CSS transformation tool
- autoprefixer 10.4.20: Adds browser-specific CSS prefixes

Scripts:
- npm run dev: Starts development server with hot module replacement
- npm run build: Creates production-optimised bundle in dist folder
- npm run preview: Previews the production build locally

### 13.2 vite.config.js

Configures the Vite build tool:
- Enables React plugin for JSX support
- Sets server host to 0.0.0.0 (accessible from network, not just localhost)
- Sets default port to 5173

### 13.3 tailwind.config.js

Configures Tailwind CSS:
- Scans all files in src/ for Tailwind class usage
- Extends the default theme with custom font-mono (IBM Plex Mono)
- Adds custom dark colour palette (dark-900 through dark-500)

### 13.4 postcss.config.js

Tells PostCSS to use Tailwind CSS and Autoprefixer plugins during CSS processing.

### 13.5 index.html

The HTML shell that loads the application:
- Sets viewport for responsive design
- Loads IBM Plex Mono font from Google Fonts CDN
- Contains a single div with id="root" where React mounts
- Loads src/main.jsx as the entry module

### 13.6 src/main.jsx

The JavaScript entry point:
- Imports React and ReactDOM
- Imports the global CSS file
- Imports the App component
- Creates a React root and renders the App inside StrictMode

### 13.7 src/index.css

Global styles:
- Tailwind base, components, and utilities directives
- Custom scrollbar styling (dark theme)
- Background colour reset for html and body
- Glow effect utility classes

### 13.8 src/App.jsx

The main application component:
- Manages state: current mode (analyse/attack/compare), token A, token B
- Runs the full analysis pipeline on every token change
- Routes to appropriate view based on mode
- Contains the header with logo, mode switcher, and pipeline steps
- Contains the ExportButtons component for SARIF/PDF/JSON downloads
- Contains the comparison logic for Dev vs Production mode

### 13.9 src/engine/constants.js

Static data used throughout the application:
- COMMON_SECRETS: Array of 50 known weak JWT secrets for basic detection
- SCOPE_KNOWLEDGE_BASE: Object mapping 60+ known scopes to their resource category, permission level, and provider
- RESOURCE_CATEGORIES: The seven categories (Users, Files, Email, Admin, Messaging, Code, General)
- RESOURCE_COLORS: Hex colour for each category used in charts
- SAMPLE_TOKENS: Four pre-built test tokens for the UI buttons

### 13.10 src/engine/decoder.js

Layer 1 implementation:
- base64urlDecode(): Converts base64url string to JSON object with padding normalisation
- detectTokenType(): Identifies token format by structure and prefix patterns
- parseToken(): Main entry function that returns the structured TokenObject

### 13.11 src/engine/ruleEngine.js

Layer 2 implementation:
- runRuleEngine(): Executes all 12 rules and returns array of findings
- extractScopes(): Helper to extract scope array from various payload formats (scope, scopes, scp, permissions)
- Each rule section clearly labelled with its ID, detection logic, and finding construction

### 13.12 src/engine/scopeAnalyser.js

Layer 3 implementation:
- analyzeScopes(): Main function that maps scopes to categories, computes blast radius, and builds D3 graph data
- buildGraphNodes(): Creates node objects for center, category, and scope nodes
- buildGraphLinks(): Creates link objects connecting nodes
- diffScopes(): Set arithmetic for compare mode (added, removed, common scopes)

### 13.13 src/engine/riskReport.js

Layer 4 implementation:
- computeRiskScore(): Capped category scoring algorithm
- getRiskLevel(): Maps score to label and visual properties
- getSeverityStyle(): Returns colours for each severity level
- generateRiskSummary(): Aggregates all data into a summary object

### 13.14 src/engine/attacks.js

Offensive security engine:
- bruteForceSecret(): Real HMAC verification using Web Crypto API against 100+ word wordlist
- generateAlgConfusionPayload(): RS256 to HS256 attack with Python exploit code
- generateAlgNonePayload(): Five unsigned token variants
- forgeToken(): Modify claims and re-sign with known secret
- generateJWKSSpoofPayload(): JWKS endpoint injection exploit
- generateClaimInjections(): 10 pre-built privilege escalation payloads
- matchCVEs(): Token characteristics to CVE matching
- generateIntruderPayloads(): Burp/ZAP fuzzer payloads
- massAnalyze(): Bulk token triage
- analyzeOAuthSecurity(): OAuth-specific vulnerability checks

### 13.15 src/components/TokenPanel.jsx

Main analysis panel UI:
- Token input textarea with placeholder and clear button
- Parse error display
- Risk score header with gauge widget
- Decoded claims table (header + payload)
- Blast radius section with radar chart and D3 graph toggle
- Findings list with expandable details, OWASP tags, and remediation code

### 13.16 src/components/D3PermissionGraph.jsx

D3.js v7 interactive graph:
- Uses useRef for SVG element reference
- Initialises D3 force simulation on mount
- Creates nodes, links, labels, tooltips
- Implements drag, zoom, and hover interactions
- Cleans up simulation on unmount

### 13.17 src/components/BlastRadiusChart.jsx

SVG radar chart:
- Computes polygon points from scope map levels
- Draws grid rings, axis lines, data polygon, and category labels
- Shows blast radius percentage in center

### 13.18 src/components/RiskGauge.jsx

Semi-circular gauge:
- Computes arc path based on score
- Draws background arc, coloured progress arc, and needle
- Shows numeric score and range labels

### 13.19 src/components/CompareView.jsx

Token comparison view:
- Score delta banner with regression warning
- Side-by-side score display (Dev vs Prod)
- Claim differences table with security-relevant highlighting

### 13.20 src/components/AttackWorkbench.jsx

Offensive toolkit UI:
- Grid of 10 attack tool buttons
- Conditional rendering of active attack panel
- Brute-force with real-time progress and result display
- Token forgery with secret and modification inputs
- Code blocks with copy buttons for all exploits
- Mass analyser with textarea input and result table

### 13.21 src/exports/sarifExport.js

SARIF 2.1.0 generator:
- Builds complete SARIF JSON structure per the OASIS specification
- Maps findings to SARIF results with rules, locations, and fixes
- Triggers browser download of .sarif file

### 13.22 src/exports/pdfExport.js

PDF report generator:
- Uses jsPDF to construct multi-page A4 document
- Cover page, executive summary, findings, scope analysis, remediation checklist
- Automatic page breaks and page numbering
- Colour-coded severity badges

### 13.23 src/exports/jsonExport.js

JSON report generator:
- Structures all analysis data into clean JSON
- Triggers browser download of .json file

### 13.24 dist/ folder

This is the production build output. Contains:
- index.html: The final HTML file
- assets/: Bundled and minified JavaScript and CSS files
- favicon.svg: Application icon

The dist folder is what gets deployed to a web server. It contains everything needed to run the app. No Node.js or npm needed to serve these files, just any static file server (Python, Nginx, Apache, Vercel, Netlify).

---

## 14. TEST TOKENS AND REAL-WORLD TESTING GUIDE

### 14.1 Built-in Test Tokens

TOKEN 1 - Critical (alg:none with admin role and wildcard scope):
```
eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiJ1c2VyXzEyMyIsInJvbGUiOiJhZG1pbiIsInNjb3BlIjoiKiIsImVtYWlsIjoiYWRtaW5AZXhhbXBsZS5jb20ifQ.
```
Decoded header: {"alg":"none","typ":"JWT"}
Decoded payload: {"sub":"user_123","role":"admin","scope":"*","email":"admin@example.com"}
Expected findings: R01 (alg:none CRITICAL), R03 (wildcard scope CRITICAL), R04 (no aud HIGH), R05 (no iss MEDIUM), R06 (role claim MEDIUM), R09 (no jti LOW), R12 (no iat/nbf LOW)

TOKEN 2 - High (jwt.io default, crackable secret):
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
```
Decoded header: {"alg":"HS256","typ":"JWT"}
Decoded payload: {"sub":"1234567890","name":"John Doe","iat":1516239022}
Secret: your-256-bit-secret (will be cracked by brute-force)
Expected findings: R01 (HS256 HIGH), R02 (no exp HIGH), R04 (no aud HIGH), R05 (no iss MEDIUM), R07 (known weak secret CRITICAL), R09 (no jti LOW)

TOKEN 3 - Over-privileged service account:
```
eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJzdmMtYWNjb3VudCIsImlzcyI6Imh0dHBzOi8vYXV0aC5leGFtcGxlLmNvbSIsImF1ZCI6Imh0dHBzOi8vYXBpLmV4YW1wbGUuY29tIiwiZXhwIjo5OTk5OTk5OTk5LCJpYXQiOjE3MDAwMDAwMDAsInNjb3BlIjoiYWRtaW46KiByZXBvIGRlbGV0ZV9yZXBvIGlhbToqIHMzOioiLCJqdGkiOiJhYmMxMjMifQ.fake-signature
```
Decoded payload: Has admin:*, repo, delete_repo, iam:*, s3:* scopes
Expected findings: R02 (excessive TTL MEDIUM), R03 (admin scope HIGH), R10 (over-privileged 5 scopes MEDIUM), R11 (no kid MEDIUM)

TOKEN 4 - Well-configured (minimal findings):
```
eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImtleS0yMDI0LTAxIn0.eyJzdWIiOiJ1c2VyXzQ1NiIsImlzcyI6Imh0dHBzOi8vYXV0aC5leGFtcGxlLmNvbSIsImF1ZCI6Imh0dHBzOi8vYXBpLmV4YW1wbGUuY29tIiwiZXhwIjoxNzEwMDAwMDAwLCJpYXQiOjE3MDk5OTY0MDAsIm5iZiI6MTcwOTk5NjQwMCwic2NvcGUiOiJyZWFkOnByb2ZpbGUgcmVhZDplbWFpbCIsImp0aSI6InVuaXF1ZS1pZC0xMjMifQ.fake-rs256-signature
```
Expected findings: R02 (token expired INFO) - this token is properly configured with RS256, kid, aud, iss, exp, iat, nbf, jti, and minimal scopes.

TOKEN 5 - Google OAuth with multiple scopes:
```
eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyQGdtYWlsLmNvbSIsImlzcyI6Imh0dHBzOi8vYWNjb3VudHMuZ29vZ2xlLmNvbSIsImF1ZCI6IjEyMzQ1Njc4OS5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsImV4cCI6MTcxMDAwMDAwMCwiaWF0IjoxNzA5OTk2NDAwLCJzY29wZSI6Imh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL2F1dGgvZ21haWwgaHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vYXV0aC9kcml2ZSBodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9hdXRoL2Nsb3VkLXBsYXRmb3JtIGh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL2F1dGgvdXNlcmluZm8ucHJvZmlsZSBodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9hdXRoL3VzZXJpbmZvLmVtYWlsIGh0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL2F1dGgvZ21haWwuc2VuZCIsImp0aSI6Imdvb2dsZS1pZC0xMjMifQ.google-signature
```
Has 6 Google scopes including gmail, drive, and cloud-platform (admin level). Tests scope analysis and blast radius visualisation.

TOKEN 6 - JWKS spoofing candidate (has jku header):
```
eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImtleS0yMDI0LTAxIiwiamt1IjoiaHR0cHM6Ly9hdXRoLmV4YW1wbGUuY29tLy53ZWxsLWtub3duL2p3a3MuanNvbiJ9.eyJzdWIiOiJ1c2VyXzEyMyIsInJvbGUiOiJ1c2VyIiwic2NvcGUiOiJyZWFkOnByb2ZpbGUiLCJhdWQiOlsiaHR0cHM6Ly9hcGkuZXhhbXBsZS5jb20iLCJodHRwczovL2FkbWluLmV4YW1wbGUuY29tIl0sImlzcyI6Imh0dHBzOi8vYXV0aC5leGFtcGxlLmNvbSIsImV4cCI6MTcxMDAwMDAwMCwiaWF0IjoxNzA5OTk2NDAwfQ.fake-rs256-sig
```
Has jku header pointing to JWKS URL. CVE matcher will flag CVE-2018-0114.

### 14.2 Compare Mode Test Tokens

Paste Token A in the DEV panel and Token B in the PROD panel:

DEV TOKEN (intentionally weak):
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkZXYtdXNlciIsInJvbGUiOiJhZG1pbiIsInNjb3BlIjoiKiIsImV4cCI6OTk5OTk5OTk5OX0.dev-signature
```

PROD TOKEN (should be tighter):
```
eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InByb2Qta2V5LTAxIn0.eyJzdWIiOiJwcm9kLXVzZXIiLCJpc3MiOiJodHRwczovL2F1dGgucHJvZC5jb20iLCJhdWQiOiJodHRwczovL2FwaS5wcm9kLmNvbSIsInNjb3BlIjoicmVhZDpwcm9maWxlIiwiZXhwIjoxNzEwMDAwMDAwLCJpYXQiOjE3MDk5OTk5MDAsImp0aSI6InByb2QtaWQtNDU2In0.prod-rs256-signature
```

The comparison will show:
- Algorithm changed from HS256 to RS256 (security improvement)
- kid added in production (improvement)
- Wildcard scope reduced to read:profile (improvement)
- iss and aud added in production (improvement)
- Role claim removed in production (improvement)
- Score delta will be negative (production is more secure)

### 14.3 Real-World Testing Guide

#### How to Get Real Tokens for Testing

Method 1 - Browser Developer Tools:
1. Login to any web application (Gmail, GitHub, AWS Console, etc.)
2. Open browser Developer Tools (F12)
3. Go to Application tab then Storage then Cookies or Local Storage
4. Look for tokens named: access_token, id_token, jwt, token, session
5. Or go to Network tab, find API requests, look for Authorization header

Method 2 - Burp Suite Proxy:
1. Configure Burp as your browser proxy
2. Browse the target application
3. In Proxy History, filter for requests with Authorization headers
4. Extract the Bearer token value

Method 3 - Mobile App Testing:
1. Use a proxy (Burp/Charles) to intercept mobile app traffic
2. Most mobile apps send JWTs in Authorization headers
3. Extract from the intercepted requests

Method 4 - API Testing:
1. Use Postman or curl to authenticate with an API
2. The response usually contains access_token and/or id_token
3. Example: curl -X POST https://auth.example.com/oauth/token -d "grant_type=client_credentials&client_id=xxx&client_secret=xxx"

#### Real-World Testing Scenarios

Scenario 1 - Bug Bounty JWT Testing:
1. Authenticate to the target application
2. Extract the JWT from cookies/localStorage/headers
3. Paste into PermissionCreep
4. If HS256 detected, use Brute-Force tool to attempt cracking
5. If secret cracks, use Forgery tool to create admin token
6. Test the forged token against the target API
7. If it works, you have a valid bug bounty finding

Scenario 2 - Penetration Test Token Audit:
1. Collect all tokens from the application (multiple user roles)
2. Use Mass Analyser to triage them quickly
3. Identify tokens with CRITICAL/HIGH findings
4. For each problematic token, try the relevant attack
5. Export SARIF report for the client
6. Export PDF report for the penetration testing deliverable

Scenario 3 - CI/CD Security Gate:
1. In your CI pipeline, generate a token using your auth server
2. Feed it to PermissionCreep (or use the JSON export format)
3. Check if risk score exceeds threshold
4. Upload SARIF to GitHub Code Scanning
5. Fail the pipeline if CRITICAL findings are present

Scenario 4 - Auth0/Okta/Azure AD Audit:
1. Get tokens from your identity provider test environment
2. Verify they follow best practices (RS256, short expiry, minimal scopes)
3. Compare development IdP tokens vs production IdP tokens
4. Check for scope creep between environments
5. Document findings in PDF report for compliance

#### What to Look For in Real Tokens

High-value findings for bug bounties:
- alg:none that is actually accepted by the server (not just in the token)
- Weak HMAC secret that can be cracked (then prove forgery works)
- Missing audience allowing cross-service replay
- Role claims that can be manipulated (with alg:none or cracked secret)
- Excessive token lifetime (especially refresh tokens)
- Wildcard scopes on user-facing tokens

How to verify a finding is exploitable:
1. Modify the token using PermissionCreep attack tools
2. Send the modified token to the actual server
3. If the server accepts it (returns 200 instead of 401/403), the vulnerability is confirmed
4. Document the request/response as proof of exploitation

### 14.4 Mass Analysis Test Data

Paste these 10 tokens (one per line) into the Mass Analyser to test bulk triage:

```
eyJhbGciOiJub25lIn0.eyJzdWIiOiJhZG1pbiJ9.
eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyMSIsImV4cCI6MTcwMDAwMDAwMH0.abc123
eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1c2VyMiIsImV4cCI6MTcxMDAwMDAwMCwiaXNfYWRtaW4iOnRydWV9.xyz789
eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyMyJ9.nosig
eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1c2VyNCIsImV4cCI6MTcxMDAwMDAwMCwic2NvcGUiOiIqIn0.star
eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyNSIsImV4cCI6MTcxMDAwMDAwMCwicm9sZSI6InVzZXIifQ.normal
eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJ1c2VyNiIsImV4cCI6MTYwMDAwMDAwMH0.expired
eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1c2VyNyIsImV4cCI6MTcxMDAwMDAwMCwicm9sZSI6ImFkbWluIn0.admintoken
eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJzdWIiOiJoYWNrZXIiLCJyb2xlIjoic3VwZXJhZG1pbiJ9.
eyJhbGciOiJSUzI1NiIsImtpZCI6ImtleTEifQ.eyJzdWIiOiJ1c2VyOSIsImV4cCI6MTcxMDAwMDAwMCwiYXVkIjoiYXBpLmV4YW1wbGUuY29tIiwiaXNzIjoiYXV0aC5leGFtcGxlLmNvbSJ9.secure
```

Expected results: Should identify 2 CRITICAL (alg:none tokens), several HIGH (no expiry, weak alg), and flag the admin tokens.

---

## 15. PROJECT FILES DELIVERED

The complete project is located at:
- Linux/WSL: /home/kali/PermissionCreep/
- Windows: C:\Users\acer\Desktop\PermissionCreep\

Contents delivered:

```
PermissionCreep/
|-- START_SERVER.bat          (Double-click to run on Windows with Python)
|-- START_SERVER.ps1          (PowerShell version of the launcher)
|-- DEV_MODE.bat              (Double-click for development mode with hot reload)
|-- package.json              (Project configuration and dependencies)
|-- package-lock.json         (Locked dependency versions for reproducible builds)
|-- vite.config.js            (Build tool configuration)
|-- tailwind.config.js        (CSS framework configuration)
|-- postcss.config.js         (CSS processing configuration)
|-- index.html                (Application HTML shell)
|-- README.md                 (Project readme with quick start)
|-- .gitignore                (Git ignore rules)
|
|-- dist/                     (Ready-to-serve production build)
|   |-- index.html
|   |-- favicon.svg
|   |-- assets/
|       |-- index-xxxxx.js    (Bundled application JavaScript)
|       |-- index-xxxxx.css   (Bundled styles)
|       |-- (other chunks)
|
|-- src/                      (Source code)
|   |-- (all source files as described in Section 13)
|
|-- public/
    |-- favicon.svg           (Application icon)
```

To run immediately: Double-click START_SERVER.bat (requires Python on Windows).
To develop: Double-click DEV_MODE.bat (requires Node.js on Windows).
To share: Send the entire PermissionCreep folder. Recipient runs START_SERVER.bat.

---

Document prepared by: Adan Raza Masoom
Air University, Islamabad - Department of Cyber Security
Solo Project Submission - Offensive Security and Vulnerability Assessment Track
